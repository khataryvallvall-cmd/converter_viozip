package com.khataryvallvall.convertervio

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.AlarmManagerCompat
import java.util.Calendar

// كل ما يخص جدولة التذكير اليومي وإنشاء قناة الإشعارات، في مكان واحد
object NotificationHelper {

    const val CHANNEL_ID = "daily_reminder_channel"
    private const val REQUEST_CODE = 1001

    // الوقت الافتراضي للتذكير اليومي — الساعة 7:00 صباحًا بالتوقيت المحلي للجهاز
    // (يُحسب على توقيت بلد المستخدم نفسه، فيصل صباحًا في كل الدول)
    // يمكن تغييره لاحقًا بسهولة من هنا فقط
    private const val DEFAULT_HOUR = 7
    private const val DEFAULT_MINUTE = 0

    fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val dailyChannel = NotificationChannel(
                CHANNEL_ID,
                "تذكير يومي",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "تذكير يومي بسيط لفتح تطبيق Converter Vio"
            }
            manager.createNotificationChannel(dailyChannel)
        }
    }

    fun scheduleDailyReminder(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, DailyReminderReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            REQUEST_CODE,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, DEFAULT_HOUR)
            set(Calendar.MINUTE, DEFAULT_MINUTE)
            set(Calendar.SECOND, 0)
            // إذا كان الوقت المحدد اليوم قد فات، يبدأ التذكير من الغد
            if (before(Calendar.getInstance())) {
                add(Calendar.DAY_OF_YEAR, 1)
            }
        }

        // منبّه للمرة القادمة فقط (يُعاد جدولته يوميًا من DailyReminderReceiver)
        // هكذا تُحسب الساعة 7:00 من جديد كل يوم بحسب التوقيت المحلي الحالي للجهاز،
        // فلا يتأثر بتغيير المنطقة الزمنية أو التوقيت الصيفي/الشتوي
        // غير دقيق بالدقيقة (فرق بضع دقائق مقبول) ولا يحتاج صلاحية خاصة على أندرويد 12+
        alarmManager.cancel(pendingIntent)
        AlarmManagerCompat.setAndAllowWhileIdle(
            alarmManager,
            AlarmManager.RTC_WAKEUP,
            calendar.timeInMillis,
            pendingIntent
        )
    }

    fun cancelDailyReminder(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, DailyReminderReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            REQUEST_CODE,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.cancel(pendingIntent)
    }
}
