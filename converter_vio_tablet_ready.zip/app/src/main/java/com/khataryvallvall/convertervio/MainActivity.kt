package com.khataryvallvall.convertervio

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.graphics.Color
import android.view.ViewGroup
import android.widget.FrameLayout
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen

class MainActivity : AppCompatActivity() {

    // يقفل حجم الخط على القيمة الطبيعية دائماً (1.0)، بغض النظر عن إعداد
    // "حجم الخط" الذي يختاره المستخدم في نظام أندرويد — يجعل التطبيق مستقلاً
    // تماماً عن إعدادات النظام في هذه النقطة، كما طُلب
    override fun attachBaseContext(newBase: Context) {
        val config = android.content.res.Configuration(newBase.resources.configuration)
        config.fontScale = 1.0f
        val context = newBase.createConfigurationContext(config)
        super.attachBaseContext(context)
    }

    private lateinit var webView: WebView
    private val ALLOWED_URL = "file:///android_asset/index.html"

    // طلب صلاحية الإشعارات وقت التشغيل (مطلوب فقط من أندرويد 13 فما فوق)
    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            NotificationHelper.scheduleDailyReminder(this)
        }
    }

    private fun setupDailyReminder() {
        NotificationHelper.createNotificationChannel(this)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED

            if (granted) {
                NotificationHelper.scheduleDailyReminder(this)
            } else {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        } else {
            // ما قبل أندرويد 13 ما فيه صلاحية وقت تشغيل مطلوبة للإشعارات
            NotificationHelper.scheduleDailyReminder(this)
        }
    }

    // جسر يفتح صفحة تحديث متصفح Chrome في متجر Play بأمان، متجاوزًا قفل
    // الـWebView الذي يمنع أي تنقّل خارجي (موجود أصلاً لحماية التطبيق)
    inner class SystemActionsBridge(private val context: Context) {
        @JavascriptInterface
        fun openChromeUpdatePage() {
            try {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.android.chrome"))
                intent.setPackage("com.android.vending")
                context.startActivity(intent)
            } catch (e: Exception) {
                try {
                    val fallback = Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse("https://play.google.com/store/apps/details?id=com.android.chrome")
                    )
                    context.startActivity(fallback)
                } catch (e2: Exception) {
                    // لا متجر متاح على الجهاز — لا يوجد إجراء بديل ممكن
                }
            }
        }
    }

    // جسر يسمح لصفحة الويب بإخبار الجهة الأصلية باللغة الحالية (ar/en/fr)
    // لبناء نصوص الإشعارات بنفس لغة المستخدم داخل التطبيق
    inner class LocaleBridge(private val context: Context) {
        @JavascriptInterface
        fun setLanguage(lang: String) {
            LocaleHelper.setLanguage(context, lang)
        }
    }

    inner class ClipboardBridge(private val context: Context) {
        @JavascriptInterface
        fun getClipboardText(): String {
            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = cm.primaryClip
            if (clip != null && clip.itemCount > 0) {
                return clip.getItemAt(0).coerceToText(context).toString()
            }
            return ""
        }

        @JavascriptInterface
        fun setClipboardText(text: String) {
            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("Converter Vio", text))
        }
    }

    // يمنع أي محاولة تنقّل داخل الـWebView لأي صفحة غير صفحتنا المحلية —
    // حتى لو حصل أي خلل مستقبلي (زي كود إعلان فيه رابط)، الصفحة الخارجية
    // مش هتقدر توصل لأي حاجة، لأنها أصلاً مش هتتحمّل جوه التطبيق
    inner class LockedWebViewClient : WebViewClient() {
        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            return request.url.toString() != ALLOWED_URL
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        // شاشة بداية سودا صافية بدون أيقونة أو اسم — بتختفي فورًا
        installSplashScreen()
        super.onCreate(savedInstanceState)

        // إغلاق صريح لأدوات فحص/تنقيح WebView عن بُعد في نسخة الإصدار النهائي
        WebView.setWebContentsDebuggingEnabled(false)

        webView = WebView(this)
        webView.layoutParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )

        // أندرويد 15 فما فوق يرسم التطبيقات بملء الشاشة (edge-to-edge) إجبارياً عند
        // targetSdk 35+. نضع الـWebView داخل حاوية سوداء ونضيف لها هوامش بقدر شريط
        // الحالة وشريط التنقل والنتوء ولوحة المفاتيح، فلا يختفي أي جزء من الواجهة تحتها.
        val container = FrameLayout(this)
        container.setBackgroundColor(Color.BLACK)
        container.addView(webView)
        setContentView(container)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowCompat.getInsetsController(window, container).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }
        ViewCompat.setOnApplyWindowInsetsListener(container) { v, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or
                    WindowInsetsCompat.Type.displayCutout() or
                    WindowInsetsCompat.Type.ime()
            )
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            WindowInsetsCompat.CONSUMED
        }

        // زر/إيماءة الرجوع بالطريقة الحديثة (onBackPressed لا تُستدعى عند targetSdk 36
        // على أندرويد 16 فما فوق)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.cacheMode = android.webkit.WebSettings.LOAD_DEFAULT
        settings.allowFileAccess = false
        settings.allowContentAccess = false
        settings.allowFileAccessFromFileURLs = false
        settings.allowUniversalAccessFromFileURLs = false
        settings.mediaPlaybackRequiresUserGesture = false
        // يمنع خط التطبيق من التأثر بإعداد "حجم الخط" في نظام أندرويد — يبقى
        // التطبيق بنفس المقاسات المصمَّمة له دائماً، بغض النظر عن إعدادات الهاتف
        settings.textZoom = 100

        webView.webViewClient = LockedWebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(ClipboardBridge(this), "AndroidClipboard")
        webView.addJavascriptInterface(LocaleBridge(this), "AndroidLocale")
        webView.addJavascriptInterface(SystemActionsBridge(this), "AndroidSystem")

        webView.loadUrl(ALLOWED_URL)

        setupDailyReminder()
    }

}
